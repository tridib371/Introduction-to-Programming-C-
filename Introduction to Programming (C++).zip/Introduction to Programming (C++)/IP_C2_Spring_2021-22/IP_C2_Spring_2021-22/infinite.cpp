#include<iostream>
using namespace std;


int main ()
{
int  i, n = 5, sum =0;
for ( i = 1; i <= n; n = n + 1 ){
	sum = sum + i;
    cout<<sum<<endl;
}
return 0;
}

