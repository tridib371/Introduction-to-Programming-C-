#include<iostream>
using namespace std;


int main()
{
    /*
    int num=1;
    while(num<=10)
    {
        cout<<num<<endl;
        num++;
    }
    return 0;*/

    int num=1;
   do{
        cout<<num<<endl;
        num++;
     }while(num<=10);

    return 0;
}
