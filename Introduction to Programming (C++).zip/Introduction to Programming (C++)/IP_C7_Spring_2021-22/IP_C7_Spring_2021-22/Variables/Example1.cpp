#include <iostream>
using namespace std;


/// Global Variable declaration:
int x, y;
float f;

int main()
{
    // Local variable
    int tot;
    float f;
    x = 10;
    y = 20;
    tot = x + y;

    cout << tot;
    cout << endl;
    f = 70.0 / 3.0;
    cout << f;
    cout << endl;
}
