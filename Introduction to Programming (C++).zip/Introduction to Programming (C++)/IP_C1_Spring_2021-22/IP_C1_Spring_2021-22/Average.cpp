#include<iostream>
using namespace std;

int main()
{
   int num1,num2,avg;
   cout<<"Enter an integer number : ";
   cin>>num1;
   cout<<"Enter an integer number : ";
   cin>>num2;

   avg=(num1+num2)/2;
   cout<<"Result is  : "<<avg<<endl;
   return 0;
}
