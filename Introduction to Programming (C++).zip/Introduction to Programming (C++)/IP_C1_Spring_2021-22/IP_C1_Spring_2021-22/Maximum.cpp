#include<iostream>
using namespace std;

int main()
{
   int num1,num2;
   cout<<"Enter an integer number : ";
   cin>>num1;
   cout<<"Enter an integer number : ";
   cin>>num2;

   if(num1>num2)
   {
       cout<<num1<<" is maximum number  "<<endl;
   }
   else
   {
       cout<<num2<<" is maximum number  "<<endl;
   }
    return 0;
}
