#include<iostream>
using namespace std;
///'A','B','C'
/// "ABC"
int main()
{
   int id,age;
   string name,address;

   cout<<" ====>> Enter your Details.... "<<endl;
   cout<<"Enter your name    : ";
   cin>>name;
   cout<<"Enter your address : ";
   cin>>address;
   cout<<"Enter your id      : ";
   cin>>id;
   cout<<"Enter your age     : ";
   cin>>age;
   cout<<endl<<endl;
   cout<<"You are "<<name<<" & you are from "<<address<<" & your age is "<<age<<" & your id is "<<id<<endl;
    return 0;
}
