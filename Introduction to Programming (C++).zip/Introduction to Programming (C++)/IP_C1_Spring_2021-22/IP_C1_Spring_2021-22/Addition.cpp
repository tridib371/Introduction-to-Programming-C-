#include<iostream>
using namespace std;

int main()
{
   int num1,num2,add;
   cout<<"Enter an integer number : ";
   cin>>num1;
   cout<<"Enter an integer number : ";
   cin>>num2;

   add=num1+num2;
   cout<<"Result is  : "<<add<<endl;
   return 0;
}
