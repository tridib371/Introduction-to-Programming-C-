#include <iostream>
#include <cmath>
using namespace std;
int main() {
	double num, squareRoot;
	cout << "Enter number: ";
	cin >> num;
	squareRoot = sqrt(num);
	cout << "The square root of " << num << " is: " << squareRoot;
	return 0;
}
