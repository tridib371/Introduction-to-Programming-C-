 #include<iostream>
 using namespace std;


 class MyClass
 {
 public:
    MyClass()
     {
         cout<<"Hello World"<<endl;
     }
 };


 int main()
 {
     MyClass obj;
     return 0;
 }
