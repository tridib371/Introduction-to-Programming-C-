#include <iostream>
using namespace std;

int main(){
   char book[50] = "A Song of Ice and Fire";
   cout<<book;
   return 0;
}
