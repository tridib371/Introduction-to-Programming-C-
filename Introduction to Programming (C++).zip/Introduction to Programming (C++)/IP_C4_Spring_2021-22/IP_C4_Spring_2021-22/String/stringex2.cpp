#include <iostream>
using namespace std;

int main(){
   string book = "A Song of Ice and Fire";
   cout<<book;
   return 0;
}

