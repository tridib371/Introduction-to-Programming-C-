#include<iostream>
using namespace std;


int main()
{
    int score[5];

    score[0] = 3;
    score[1] = 4;
    score[2] = 5;
    score[3] = 6;
    score[4] = 7;

    cout<<"Value for third variable : "<<score[2]<<endl;

        return 0;
}
