#include<iostream>
using namespace std;


int main()
{
    int score[5]={3,4,5,6,7};
    cout<<"Value for third variable : "<<score[2]<<endl;

        return 0;
}

